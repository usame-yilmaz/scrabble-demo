package com.scrabble.validation;

import com.scrabble.aop.ScrabbleValidationComponent;
import com.scrabble.controller.GameController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.validation.MapBindingResult;
import org.springframework.validation.Validator;

import java.util.Map;

public class CreateBoardValidator {


    private CreateBoardValidator() {
    }

    @ScrabbleValidationComponent
    public static class CheckBoard implements Validator {


        @Autowired
        CheckBoard() {
        }

        @Override
        public boolean supports(Class<?> aClass) {
            return GameController.class.equals(aClass);
        }

        @Override
        public void validate(Object o, Errors errors) {
            MapBindingResult result = (MapBindingResult) errors;
            // Get method parameters
            Map params = result.getTargetMap();
            // Find the parameter using its name and use it
           
        }
    }
}
