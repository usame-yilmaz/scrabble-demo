package com.scrabble.service;

import com.scrabble.model.Board;
import com.scrabble.model.Game;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class GameService {
    
    public void addBoardToGame(Board board) {
        // Get instance from singleton object
        Game game = Game.getInstance();
        game.getBoards().add(board);
    }
}
