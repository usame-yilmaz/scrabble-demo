package com.scrabble.service;

import com.scrabble.model.Board;
import com.scrabble.model.PositionEnum;
import com.scrabble.model.StatusEnum;
import com.scrabble.model.Word;
import com.scrabble.repository.BoardJpaRespository;
import com.scrabble.repository.WordJpaRespository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@Transactional
public class BoardService {
    @Autowired
    BoardJpaRespository boardJpaRespository;
    @Autowired
    WordJpaRespository wordJpaRespository;
    
    public Board createBoard() {
        Board board = Board.builder().playOrder(1).deactivated(false).status(StatusEnum.PASSIVE).build();

        // TODO: 13.01.2020 silinecek 
        Word word = Word.builder().board(board).characters("araba").position(PositionEnum.HORIZONTAL).startCol(1).startRow(2).build();
        Word word2 = Word.builder().board(board).characters("kamyon").position(PositionEnum.HORIZONTAL).startCol(1).startRow(2).build();
        board.setWords(new HashSet<>(Arrays.asList(word,word2)));
        return boardJpaRespository.save(board);
    }

    public Set<String> getWords(Long boardId) {
        
        Board board = boardJpaRespository.findOne(boardId);
        return board.getWords().stream().map(Word::getCharacters).collect(Collectors.toSet());
    }
}
