package com.scrabble.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


@Builder
@Setter
@Getter
public class Cell {
    private Boolean occupied = false;
    private Character character;

}
