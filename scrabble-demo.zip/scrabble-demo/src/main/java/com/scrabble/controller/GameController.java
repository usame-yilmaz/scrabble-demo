package com.scrabble.controller;

import com.scrabble.aop.ScrabbleValidator;
import com.scrabble.model.Board;
import com.scrabble.model.Game;
import com.scrabble.model.Move;
import com.scrabble.model.Tile;
import com.scrabble.service.BoardService;
import com.scrabble.service.GameService;
import com.scrabble.validation.CreateBoardValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Set;

@RestController
@RequestMapping("/game")
public class GameController {

    @Autowired
    private BoardService boardService;
    @Autowired
    private GameService gameService;

    /**
	 * Used to create a Board in DB
	 *
	 * @return the {@link com.scrabble.model.Board} created
	 */
    @PostMapping(value = "/createBoard")
    @ScrabbleValidator(validator = CreateBoardValidator.CheckBoard.class)
    public ResponseEntity<Long> createBoard() {
        
        Board board = boardService.createBoard();
        gameService.addBoardToGame(board);
        
        return ResponseEntity.ok(board.getId());
    }

    /**
     * Used to play
     */
    @PostMapping(value = "/play")
    public ResponseEntity<Long> play(List<Move> moves) {

        return ResponseEntity.ok(1L);
    }

    /**
     * Get words of the board
     */
    @PostMapping(value = "/getWords")
    public ResponseEntity<Set<String>> getWords(Long boardId) {

        return ResponseEntity.ok(boardService.getWords(boardId));
    }
}
